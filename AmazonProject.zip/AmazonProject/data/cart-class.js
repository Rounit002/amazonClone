class Cart {
    cart=undefined;
    dataName=undefined;
    loadCartPage() {
    
        this.cart=JSON.parse(localStorage.getItem(this.dataName));
       
       if (!this.cart) {
        this.cart=[{
               productId: '1005dinnerSet',
               quantity:1,
               deliveryOptionId:1
           },{
               productId: '1006nonsticbakeware',
               quantity:1,
               deliveryOptionId:2
           }]; 
               }
       }
        saveToStorage() {
        localStorage.setItem(this.dataName,JSON.stringify(this.cart));
    }
    getCartLength() {
        return this.cart.length;
    }
    addToCart(productId) {
    
        let matchingItem;
    
        this.cart.forEach((item) => {
                if (productId===item.productId) {
                    matchingItem=item;
                }
            
        });
    
        if (matchingItem) {
            matchingItem.quantity+=1;
        }else{
            this.cart.push({
                productId: productId,
                quantity: 1,
                deliveryOptionId:1
            });
        }
    
        this.saveToStorage();
    }
    cartQuantity() {
    
        let totalQuantity=0;
    
        this.cart.forEach((item)=>{
            totalQuantity=totalQuantity+item.quantity;
        })
    
        document.querySelector('.rightsec .cartQuantity').innerHTML=totalQuantity;
    }

    removeCart(productId) {
    
        const newCart=[];
    
        this.cart.forEach((cartItem)=>{
            if (cartItem.productId!==productId) {
                newCart.push(cartItem);
            }
        });
    
        this.cart=newCart;
    
        this.saveToStorage();
    }

    updateDeliveryOption(productId, deliveryOptionId) {
    
        let matchingItem;
    
        this.cart.forEach((item) => {
                if (productId===item.productId) {
                    matchingItem=item;
                }
            
        });
    
        matchingItem.deliveryOptionId=deliveryOptionId;
        saveToStorage();
    }

}



console.log(cartOld);
console.log(cartBussniess);