export let cart=JSON.parse(localStorage.getItem('cart'));

if (!cart) {
    cart=[{
        productId: '1005dinnerSet',
        quantity:1,
        deliveryOptionId:1
    },{
        productId: '1006nonsticbakeware',
        quantity:1,
        deliveryOptionId:2
    }]
}

function saveToStorage() {
    localStorage.setItem('cart',JSON.stringify(cart));
}

export function getCartLength() {
    return cart.length;
}

export function addToCart(productId) {
    
    let matchingItem;

    cart.forEach((item) => {
            if (productId===item.productId) {
                matchingItem=item;
            }
        
    });

    if (matchingItem) {
        matchingItem.quantity+=1;
    }else{
        cart.push({
            productId: productId,
            quantity: 1,
            deliveryOptionId:1
        });
    }

    saveToStorage();
}

export function cartQuantity() {
    
    let totalQuantity=0;

    cart.forEach((item)=>{
        totalQuantity=totalQuantity+item.quantity;
    })

    document.querySelector('.rightsec .cartQuantity').innerHTML=totalQuantity;
}

export function removeCart(productId) {
    
    const newCart=[];

    cart.forEach((cartItem)=>{
        if (cartItem.productId!==productId) {
            newCart.push(cartItem);
        }
    });

    cart=newCart;

    saveToStorage();
}

export function updateDeliveryOption(productId, deliveryOptionId) {
    
    let matchingItem;

    cart.forEach((item) => {
            if (productId===item.productId) {
                matchingItem=item;
            }
        
    });

    matchingItem.deliveryOptionId=deliveryOptionId;
    saveToStorage();
}