export function getProduct(productId) {
    let matchingProduct;

products.forEach((product)=>{
    if (product.Id===productId) {
        matchingProduct=product;
    }

});
    return matchingProduct;
}

class Product {
    Id;
    image;
    name;
    rating;
    priceCents;

    constructor(productDetails){
        this.Id=productDetails.Id;
        this.image=productDetails.image;
        this.name=productDetails.name;
        this.rating=productDetails.rating;
        this.priceCents=productDetails.priceCents;
    }

    getStarsURL(){
        return `../images/ratings/rating-${this.rating.stars*10}.png`;
    }

    getPriceCents() {
       return `$${(this.priceCents/100).toFixed(2)}`;
    }

    extraInfo(){
        return '';
    }
}

class Clothing extends Product {
    sizeChartImg;

    constructor(productDetails){
        super(productDetails);
        this.sizeChartImg=productDetails.sizeChartImg;
    }

    extraInfo(){
        return `
        <a href="${this.sizeChartImg}" target="_blank" >Size Chart</a>`;
    }
}

class Appliance extends Product {
    instructionLink;
    WarrantyLink;

    constructor(productDetails){
        super(productDetails);
        this.instructionLink=productDetails.instructionLink;
        this.WarrantyLink=productDetails.WarrantyLink;
    }

    extraInfo(){
        return `
        <a href="${this.instructionLink}" target="_blank" >Instructions</a>
       , <a href="${this.WarrantyLink}" target="_blank" >Warranty</a>`;
        
    }
}

export const products =[
    {
        Id:"1001bgsocks",
        image:'../images/products/athletic-cotton-socks-6-pairs.jpg',
        name:'Black and Gray Athletic Cotton-Socks-6-Pairs',
        rating: {
            stars:4.5,
            ratingCount:87
        },
        priceCents:1090,
        typeOf:'clothing',
        sizeChartImg:'../images/clothing-size-chart.png'
       
    },{
        Id:"1002ImBasketball",
        image:'../images/products/intermediate-composite-basketball.jpg',
        name:'Intermediate Size Basketball',
        rating: {
            stars:4,
            ratingCount:127
        },
        priceCents:2095
       
    },{

        Id:"1003apCotton2tshirt",
        image:'../images/products/adults-plain-cotton-tshirt-2-pack-teal.jpg',
        name:'Adults Plain Cotton T-Shirt - 2 Pack',
        rating: {
            stars:4.5,
            ratingCount:56
        },
        priceCents:799,
        typeOf:'clothing',
        sizeChartImg:'../images/clothing-size-chart.png'
       
    },{
        Id:"1004slotTostar",
        image:'../images/products/black-2-slot-toaster.jpg',
        name:'2 Slot Toaster - Black',
        rating: {
            stars:5,
            ratingCount:2197
        },
        priceCents:1899,
        typeOf:'Appliance',
        instructionLink:'../images/appliance-instructions.png',
        WarrantyLink:'../images/appliance-warranty.png',
       
    },{
        Id:"1005dinnerSet",
        image:'../images/products/6-piece-white-dinner-plate-set.jpg',
        name:'6 Piece White Dinner Plate Set',
        rating: {
            stars:4,
            ratingCount:2197
        },
        priceCents:2067
       
    },{
        Id:"1006nonsticbakeware",
        image:'../images/products/6-piece-non-stick-baking-set.webp',
        name:'6-Piece Nonstick, Carbon Steel Oven Bakeware',
        rating: {
            stars:4.5,
            ratingCount:175
        },
        priceCents:3499,
        typeOf:'Appliance',
        instructionLink:'../images/appliance-instructions.png',
        WarrantyLink:'../images/appliance-warranty.png',
       
    },{
        Id:"1007PHfleSwetshirt",
        image:'../images/products/plain-hooded-fleece-sweatshirt-yellow.jpg',
        name:'Plain Hooded Fleece Sweatshirt',
        rating: {
            stars:4.5,
            ratingCount:317
        },
        priceCents:2400,
        typeOf:'clothing',
        sizeChartImg:'../images/clothing-size-chart.png'
       
    },{
        Id:"1008luxytowelgrey",
        image:'../images/products/luxury-tower-set-6-piece.jpg',
        name:'Luxury Towel Set - Graphite Gray',
        rating: {
            stars:4.5,
            ratingCount:144
        },
        priceCents:3599
       
    },{
        Id:"1009liquiddetergent",
        image:'../images/products/liquid-laundry-detergent-plain.jpg',
        name:'Liquid Laundry Detergent, 110 Loads, 82.5 Fl Oz',
        rating: {
            stars:4.5,
            ratingCount:305
        },
        priceCents:2899
       
    },{
        Id:"1010waterproofsneakers",
        image:'../images/products/knit-athletic-sneakers-gray.jpg',
        name:'Waterproof Knit Athletic Sneakers - Gray',
        rating: {
            stars:4.5,
            ratingCount:89
        },
        priceCents:3390
       
    },{
        Id:"1011beachwearBlack",
        image:'../images/products/women-chiffon-beachwear-coverup-black.jpg',
        name:`Women's Chiffon Beachwear Cover Up - Black`,
        rating: {
            stars:4.5,
            ratingCount:235
        },
        priceCents:2070,
        typeOf:'clothing',
        sizeChartImg:'../images/clothing-size-chart.png'       
    },{
        Id:"1012sunGlassRound",
        image:'../images/products/round-sunglasses-black.jpg',
        name:'Round Sunglasses',
        rating: {
            stars:4.5,
            ratingCount:30
        },
        priceCents:1560
       
    },
].map((productDetails)=>{
    if (productDetails.typeOf==='clothing') {
        return new Clothing(productDetails);
    } 
    if (productDetails.typeOf==='Appliance') {
        return new Appliance(productDetails);
    }
   return new Product(productDetails);
});