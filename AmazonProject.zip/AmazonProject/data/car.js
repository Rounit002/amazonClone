class Car {
    brand;
    model;
    speed;
    isTrunkOpen;

    constructor(carDetails){
        this.brand=carDetails.brand;
        this.model=carDetails.model;
        this.speed=carDetails.speed;
        this.isTrunkOpen=carDetails.isTrunkOpen;
    }

    displayInfo(){
        const details= `${this.brand} ${this.model}, ${this.speed} km/h , ${this.isTrunkOpen}`;
        console.log(details);
    }

    go(){
        this.speed=this.speed+5;
    }

    brake(){
        this.speed=Math.max(0,this.speed-5);
        // this.speed=this.speed-5;   
    }

    openTrunk(){
        if (this.speed>0) {
            console.log('Stop the Car');
        }else{
        this.isTrunkOpen='Trunk is Open now';
        console.log(this.isTrunkOpen);}
    }

    closeTrunk(){
        if (this.speed<=0) {
            this.isTrunkOpen='Trunk is Closed';
        }
    }


}

export const cars=[ {
    brand:'Toyota',
    model:'Corolla',
    speed:0,
    isTrunkOpen:'Closed'
},
{
brand:'Tesla',
model:'Model 3',
speed:0,
isTrunkOpen:''
},
].map((carDetails)=>{
    return new Car(carDetails)
})

console.log(cars);
cars.forEach(car => car.displayInfo());

cars[1].go();
cars[1].displayInfo(); 

cars[0].brake();
cars[0].displayInfo();

cars[0].openTrunk();
cars[0].displayInfo();

cars[1].brake();
cars[1].displayInfo();

cars[1].openTrunk();
cars[1].displayInfo();