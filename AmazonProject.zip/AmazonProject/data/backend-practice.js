// const xhr= new XMLHttpRequest();

// xhr.addEventListener('load',()=>{
//     console.log(xhr.response);
// });

// xhr.open('GET','https://supersimplebackend.dev');
// xhr.send();


// function loadFetch(){
//     fetch('https://supersimplebackend.dev/products').then((response)=>{
//         return response.json()
//     }).then((productsData)=>{
//         console.log(productsData);
//     })
// }


async function loadFetch(){
    try {     
   const Anew= await fetch('https://supersimplebackend.dev/products').then((response)=>{
        return response.json()
    })
    console.log(Anew);
    } catch (error) {
        console.log('it will be fixed soon')
    }
    
}

loadFetch()