import { cart,getCartLength } from '../data/cart.js';
import {getProduct} from '../data/products.js';
import {getDeliveryOptions } from '../data/deliveryOptions.js';

export function renderPaymentSummary() {
    let productPriceCents=0;
    let shippingPriceCents=0;

    cart.forEach((cartItem) => {
        const product=getProduct(cartItem.productId);
        const newPrice=product.priceCents*cartItem.quantity;
        productPriceCents+=newPrice;

        const deliveryOption=getDeliveryOptions(cartItem.deliveryOptionId);
        shippingPriceCents+= deliveryOption.priceCents;
    });

    const totalBeforeTax= productPriceCents+shippingPriceCents;
    
    const estimatedTax= (totalBeforeTax)*(10/100);
    
    const orderTotal=totalBeforeTax+estimatedTax;

    let paymentSummaryHTML='';

 paymentSummaryHTML+=`
    
     <div class="summary-heading">Order Summary</div>
        <div class="all-charges">
            <div class="recipt"> <p>Items(${cart.length}):</p>
                  <p>Shipping & handling:</p>
                  <p>Total before tax:</p>
                  <p>Estimated tax(10%):</p>
                  <hr>
                  <p class="total-order">Order total:</p>
                  <p class="paypal">Use PayPal <input class="paypal-payment" type="checkbox" name="" id=""></p>
            </div>
            <div class="price"> <p>$${(Math.round(productPriceCents)/100).toFixed(2)}</p>
                  <p> $${(Math.round(shippingPriceCents)/100).toFixed(2)}</p>
                  <p>$${(Math.round(totalBeforeTax)/100).toFixed(2)}</p>
                  <p> $${(Math.round(estimatedTax)/100).toFixed(2)}</p>
                  <hr>
                  <p class="total-price">$${(Math.round(orderTotal)/100).toFixed(2)}</p>
            </div>
            <div class="to-order">
            <button class="place-order js-place-order">Place your order</button>
        </div>
        </div>`;

    document.querySelector('.order-summary-container .js-paymentSummary').innerHTML=paymentSummaryHTML;

};

export function pushToOrders() {
    document.querySelector('.js-place-order').addEventListener('click', () => {
        let orders = JSON.parse(localStorage.getItem('orders')) || [];
    
        cart.forEach((cartItemss) => {
            const productOrders = getProduct(cartItemss.productId);
            const orderItem = {
                id: cartItemss.productId,
                name: productOrders.name,
                image: productOrders.image,
                quantity: cartItemss.quantity,
                price: (productOrders.priceCents * cartItemss.quantity) / 100,
                orderDate: new Date().toDateString(),
                estimatedDelivery: 'February 6'
            };
            orders.push(orderItem);
        });
    
        localStorage.setItem('orders', JSON.stringify(orders));
    
        // Clear the cart
        localStorage.removeItem('cart');
    
        // Redirect to orders page
        window.location.href = 'orders.html';
    });
    
};