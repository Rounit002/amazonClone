import { cart,removeCart,getCartLength,updateDeliveryOption} from '../data/cart.js';

import { products,getProduct } from '../data/products.js';
import dayjs from 'https://unpkg.com/dayjs@1.11.10/esm/index.js';
import { deliveryOptions, getDeliveryOptions} from '../data/deliveryOptions.js';
import {renderPaymentSummary} from '../checkout/paymentSummary.js';

const today=dayjs();
const deliveryDate=today.add(7,'days');
const readAble=deliveryDate.format('dddd, MMMM D');
 
export function renderOrderSummary() {

let cartItems='';
cart.forEach((displayed)=>{

const productId=displayed.productId;
const matchingProduct=getProduct(productId);

const deliveryOptionId = displayed.deliveryOptionId;

const deliveryOption=getDeliveryOptions(deliveryOptionId);



const today =dayjs();
        const deliveryDate= today.add(
            deliveryOption.deliveryDays,
            'days'
        );

        const readDate=deliveryDate.format('dddd, MMMM D');


cartItems+=`
           <div class="cart-detail js-${matchingProduct.Id}">    
            <div class="cart-added-product">
                
                <div class="all-detail">
                <div class="delivery-time">
                    Delivery date: ${readDate}
                </div>
                <div class="added-product-detail">
                <div class="added-image">
                    <img src="${matchingProduct.image}" alt="">
                </div>
    
                <div class="added-all-detail">
                    <p class="name">${matchingProduct.name}</p>
    
                    <p class="price">${matchingProduct.getPriceCents()}</p>
                <p class="selected-quantity">
                    Quantity: ${displayed.quantity}
                    <button class="cart-update"
                    data-update-id="${matchingProduct.Id}">Update</button>

                    <input class="quantity-input" type="number"></input>
                    <span class="save-quantity-link link-primary">Save</span>

                    <button class="cart-delete" 
                    data-product-id="${matchingProduct.Id}">Delete</button>
                </p>
                </div>
    
                <div class="delivery-option">
                    <p class="choose">Choose a delivery option:</p>
    
                         ${deliveryOptionHTML(matchingProduct, displayed)}               
                </div>
                </div>
            
                </div>
            </div>    
        </div>`;

});

function deliveryOptionHTML(matchingProduct, displayed) {

    let html='';

    deliveryOptions.forEach((option) => {

        const today =dayjs();
        const deliveryDate= today.add(
            option.deliveryDays,
            'days'
        );

        const readDate=deliveryDate.format('dddd, MMMM D');

        // const price=(deliveryOptions.priceCents/100).toFixed(2);

        const priceString=option.priceCents===0 ? 'Free' : `${matchingProduct.getPriceCents()} -`;

        const isChecked = (option.id) === displayed.deliveryOptionId;

        html+=`<div class="options js-deliveryFuntction"
                data-product-id="${matchingProduct.Id}"
                data-delivery-option-id="${option.id}">
                    <p class="input1">
                        <input type="radio" 
                        ${isChecked ? 'checked' : ''}
                        name="name-${matchingProduct.Id}" id="">${readDate}<br>
                        <span class="devilery-charge"> ${priceString} Shipping</span>
                    </p>    
              </div>`
    });

    return html;
}

document.querySelector('.checkout-container').innerHTML=cartItems;
document.querySelector('.mid-sec .item-counter').innerHTML=`Checkout: ${getCartLength()} item`;


const deleteLink= document.querySelectorAll('.selected-quantity .cart-delete');

deleteLink.forEach((link)=>{

    link.addEventListener('click',()=>{
        const productId=link.dataset.productId;
        removeCart(productId);
        
       const container= document.querySelector(`.js-${productId}`);
        container.remove();
        document.querySelector('.mid-sec .item-counter').innerHTML=`Checkout: ${getCartLength()} item`;
        renderPaymentSummary();
    });
});

const updatingDate=document.querySelectorAll('.js-deliveryFuntction');
updatingDate.forEach((updatedDate)=>{
    updatedDate.addEventListener('click',()=>{
        const productId=updatedDate.dataset.productId;
        const deliveryOptionId=String(updatedDate.dataset.deliveryOptionId);
        updateDeliveryOption(productId, deliveryOptionId);
        renderOrderSummary();
        renderPaymentSummary();
    });
});

}

renderOrderSummary();