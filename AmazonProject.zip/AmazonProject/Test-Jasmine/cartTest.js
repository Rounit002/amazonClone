import {addToCart,cart } from '../data/cart.js';

describe('test suite: addTocart', ()=>{
    it('adds an existing product to the cart', ()=>{

      
    });

    it('adds a new product to the cart', ()=>{
        spyOn(localStorage, 'getItem').and.callFake(()=>{
            return JSON.stringify([]);
        });

        console.log(localStorage.getItem('cart'))
        addToCart('005dinnerSet');
        expect(cart.length).toEqual(1);
    })
})