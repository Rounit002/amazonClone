import{cart,addToCart,cartQuantity,getCartLength} from '../data/cart.js';
import{products} from '../data/products.js';
let productsHTML='';

products.forEach((product) => {
    productsHTML+=`
    <div class="product-image">
    <div class="description">
        <div class="only-image">
            <img src="${product.image}" alt="">
        </div>

    <div class="product-detail-container">
        <div class="product-name">
            <p class="product-title">${product.name}</p>
        </div>

        <div class="product-ratings">
            <img src=${product.getStarsURL()} alt="">

            <div class="rating-count">
                ${product.rating.ratingCount}
            </div>
        </div>

    <div class="product-cost">
        <p class="cost">${product.getPriceCents()}</p>
    </div>

            <div class="quantity-selector">
            <select name="product-quantity" id="product-quantity"
            class="quantity-selected">
                <option selected value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
            </div>
        </div>

             ${product.extraInfo()}

            <div class="cart-confirmation">✅ Added</div>
            <div class="cart">
                <button class="add-to-cart"
                data-product-id="${product.Id}">Add to Cart</button>
            </div> 
        </div>
    </div>`;
   
});

document.querySelector('.products').innerHTML=productsHTML;
document.querySelector('.cart-icon .cartQuantity').innerHTML=getCartLength();

document.querySelectorAll('.add-to-cart').forEach((button)=>{button.addEventListener('click',()=>{
    const productId=button.dataset.productId;
    addToCart(productId);
    cartQuantity();    
});
});