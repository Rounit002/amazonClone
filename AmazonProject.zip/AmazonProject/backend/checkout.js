import {renderOrderSummary} from '../checkout/orderSummary.js';
import {renderPaymentSummary,pushToOrders} from '../checkout/paymentSummary.js';
// import '../data/car.js';
// import '../data/backend-practice.js';





renderOrderSummary();
renderPaymentSummary();
pushToOrders();