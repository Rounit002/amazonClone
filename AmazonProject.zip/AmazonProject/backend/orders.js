import {cart,getCartLength} from '../data/cart.js';
// import { renderPaymentSummary } from '../checkout/paymentSummary.js';

document.addEventListener('DOMContentLoaded', () => {
    const ordersContainer = document.querySelector('.product-inside-orders');

    let orders = JSON.parse(localStorage.getItem('orders')) || [];

    let ordersHTML = '';

    orders.forEach(order => {
        ordersHTML += `
<div class="all-order-list">
    <div class="ordered-products">

            <div class="date-of-order">Order Placed 
                <br><span>${order.orderDate}</span>
            </div>

            <div class="total-order-price">Total
                <br><span>$${order.price.toFixed(2)}</span>
            </div>

            <div class="ordered-Id">
                Order-ID:
                <br><span>${order.id}</span>
            </div>

            <hr><hr><hr>

            <div class="all-details">

                        <div class="ordered-product-image">
                        <img src="${order.image}" alt="">
                        </div>

                        <div class="ordered-details">
                            <div class="product-name">${order.name}</div>
                            <div class="delivery-date">Arriving on: ${order.estimatedDelivery}</div>
                            <div class="quantity-ordered">Quantity: ${order.quantity}</div>
                            <button class="buy-again">
                                <img src="../images/icons/buy-again.png" alt=""> Buy it again
                            </button>
                            
                        </div>
                        <button class="track-package">Track package</button>
            </div>
    </div>
</div> `;
    });

    ordersContainer.innerHTML = ordersHTML;
});

document.querySelector('.rightsec .cartQuantity-order-list').innerHTML=getCartLength();
